/**
 * COMET Browser Extension - Content Script
 * Injetado em todas as páginas para controle avançado
 */

console.log('COMET Extension: Content script carregado');

// Listener para mensagens do background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Content script recebeu mensagem:', request);
  
  switch (request.action) {
    case 'getPageInfo':
      sendResponse({
        url: window.location.href,
        title: document.title,
        html: document.documentElement.outerHTML.substring(0, 1000)
      });
      break;
      
    case 'executeScript':
      try {
        const result = eval(request.code);
        sendResponse({ success: true, result: result });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
      break;
      
    case 'highlight':
      highlightElement(request.selector);
      sendResponse({ success: true });
      break;
      
    default:
      sendResponse({ success: false, error: 'Ação desconhecida' });
  }
  
  return true; // Mantém o canal aberto para resposta assíncrona
});

/**
 * Destaca elemento na página
 */
function highlightElement(selector) {
  const element = document.querySelector(selector);
  if (element) {
    element.style.outline = '3px solid red';
    element.style.outlineOffset = '2px';
    
    setTimeout(() => {
      element.style.outline = '';
      element.style.outlineOffset = '';
    }, 2000);
  }
}

/**
 * Observa mudanças no DOM
 */
const observer = new MutationObserver((mutations) => {
  // Pode ser usado para detectar mudanças dinâmicas
  // e notificar o background script
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Notifica que o content script está pronto
chrome.runtime.sendMessage({ 
  type: 'content_ready',
  url: window.location.href 
});
