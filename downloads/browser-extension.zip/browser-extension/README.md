# COMET Browser Extension

Extensão Chrome para automação remota integrada com o Desktop Agent.

## Instalação

1. Abra o Chrome e vá para `chrome://extensions/`
2. Ative o "Modo do desenvolvedor" (canto superior direito)
3. Clique em "Carregar sem compactação"
4. Selecione a pasta desta extensão

## Funcionalidades

- ✅ Conexão WebSocket com Desktop Agent local
- ✅ Navegação automática de páginas
- ✅ Clique em elementos
- ✅ Preenchimento de formulários
- ✅ Captura de screenshots
- ✅ Listagem de abas abertas
- ✅ Execução de scripts personalizados
- ✅ Interface de status em tempo real

## Requisitos

- Chrome 88+ ou Edge 88+
- Desktop Agent em execução (porta 8765)

## Estrutura

```
browser-extension/
├── manifest.json       # Configuração da extensão
├── background.js       # Service worker (conexão WebSocket)
├── content.js          # Script injetado nas páginas
├── popup.html          # Interface do usuário
├── popup.js            # Lógica do popup
├── icons/              # Ícones da extensão
└── README.md           # Este arquivo
```

## Uso

1. Certifique-se de que o Desktop Agent está em execução
2. Clique no ícone da extensão para ver o status
3. A extensão se conectará automaticamente ao agent local
4. Use o painel de controle para enviar comandos

## Comandos Suportados

- `navigate` - Navegar para URL
- `click` - Clicar em elemento (seletor CSS)
- `fill` - Preencher input (seletor CSS + valor)
- `screenshot` - Capturar screenshot da aba ativa
- `get_tabs` - Listar todas as abas abertas

## Desenvolvimento

Para modificar a extensão:

1. Edite os arquivos necessários
2. Vá para `chrome://extensions/`
3. Clique no botão "Atualizar" da extensão

## Segurança

- A extensão só se conecta a `localhost:8765`
- Todas as comunicações são locais (sem internet)
- Requer permissões explícitas do usuário

## Licença

Propriedade de Rudson Oliveira - Sistema COMET
