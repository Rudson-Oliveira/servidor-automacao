/**
 * COMET Browser Extension - Background Service Worker
 * Gerencia conexão WebSocket com Desktop Agent
 */

const AGENT_URL = 'ws://localhost:8765';
let websocket = null;
let reconnectInterval = null;
let isConnected = false;

// Estado da extensão
const state = {
  agentConnected: false,
  lastHeartbeat: null,
  pendingCommands: new Map()
};

/**
 * Conecta ao Desktop Agent local
 */
function connectToAgent() {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    console.log('Já conectado ao agent');
    return;
  }

  console.log('Conectando ao Desktop Agent...');
  
  try {
    websocket = new WebSocket(AGENT_URL);
    
    websocket.onopen = () => {
      console.log('✓ Conectado ao Desktop Agent');
      isConnected = true;
      state.agentConnected = true;
      
      // Limpar intervalo de reconexão
      if (reconnectInterval) {
        clearInterval(reconnectInterval);
        reconnectInterval = null;
      }
      
      // Enviar handshake
      sendMessage({
        type: 'handshake',
        source: 'browser-extension',
        version: chrome.runtime.getManifest().version
      });
      
      // Atualizar badge
      updateBadge('ON', '#00ff00');
    };
    
    websocket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        handleAgentMessage(message);
      } catch (error) {
        console.error('Erro ao processar mensagem:', error);
      }
    };
    
    websocket.onerror = (error) => {
      console.error('Erro no WebSocket:', error);
      updateBadge('ERR', '#ff0000');
    };
    
    websocket.onclose = () => {
      console.log('Desconectado do Desktop Agent');
      isConnected = false;
      state.agentConnected = false;
      updateBadge('OFF', '#999999');
      
      // Tentar reconectar
      if (!reconnectInterval) {
        reconnectInterval = setInterval(connectToAgent, 5000);
      }
    };
    
  } catch (error) {
    console.error('Erro ao conectar:', error);
    updateBadge('OFF', '#999999');
  }
}

/**
 * Envia mensagem para o agent
 */
function sendMessage(message) {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    websocket.send(JSON.stringify(message));
    return true;
  }
  return false;
}

/**
 * Processa mensagens recebidas do agent
 */
function handleAgentMessage(message) {
  console.log('Mensagem do agent:', message);
  
  switch (message.type) {
    case 'command':
      executeCommand(message);
      break;
      
    case 'pong':
      state.lastHeartbeat = Date.now();
      break;
      
    case 'ack':
      console.log('Handshake confirmado');
      break;
      
    default:
      console.log('Tipo de mensagem desconhecido:', message.type);
  }
}

/**
 * Executa comando recebido do agent
 */
async function executeCommand(message) {
  const { command_id, command_type, params } = message;
  
  console.log(`Executando comando: ${command_type} (ID: ${command_id})`);
  
  let result = {};
  
  try {
    switch (command_type) {
      case 'navigate':
        result = await navigateToUrl(params.url);
        break;
        
      case 'click':
        result = await clickElement(params.selector);
        break;
        
      case 'fill':
        result = await fillInput(params.selector, params.value);
        break;
        
      case 'screenshot':
        result = await captureScreenshot();
        break;
        
      case 'get_tabs':
        result = await getTabs();
        break;
        
      default:
        result = { success: false, error: `Comando não suportado: ${command_type}` };
    }
  } catch (error) {
    result = { success: false, error: error.message };
  }
  
  // Enviar resultado
  sendMessage({
    type: 'command_result',
    command_id: command_id,
    result: result
  });
}

/**
 * Navega para URL
 */
async function navigateToUrl(url) {
  try {
    const tab = await chrome.tabs.create({ url: url });
    return { success: true, tab_id: tab.id };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Clica em elemento
 */
async function clickElement(selector) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (sel) => {
        const element = document.querySelector(sel);
        if (element) {
          element.click();
          return { success: true };
        }
        return { success: false, error: 'Elemento não encontrado' };
      },
      args: [selector]
    });
    
    return result[0].result;
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Preenche input
 */
async function fillInput(selector, value) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (sel, val) => {
        const element = document.querySelector(sel);
        if (element) {
          element.value = val;
          element.dispatchEvent(new Event('input', { bubbles: true }));
          element.dispatchEvent(new Event('change', { bubbles: true }));
          return { success: true };
        }
        return { success: false, error: 'Elemento não encontrado' };
      },
      args: [selector, value]
    });
    
    return result[0].result;
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Captura screenshot
 */
async function captureScreenshot() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    
    return { 
      success: true, 
      image: dataUrl.split(',')[1] // Remove data:image/png;base64,
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Obtém lista de abas
 */
async function getTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    const tabList = tabs.map(tab => ({
      id: tab.id,
      url: tab.url,
      title: tab.title,
      active: tab.active
    }));
    
    return { success: true, tabs: tabList };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Atualiza badge da extensão
 */
function updateBadge(text, color) {
  chrome.action.setBadgeText({ text: text });
  chrome.action.setBadgeBackgroundColor({ color: color });
}

/**
 * Heartbeat periódico
 */
function startHeartbeat() {
  setInterval(() => {
    if (isConnected) {
      sendMessage({ type: 'ping' });
    }
  }, 30000); // 30 segundos
}

// Inicialização
chrome.runtime.onInstalled.addListener(() => {
  console.log('COMET Browser Extension instalada');
  updateBadge('OFF', '#999999');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('COMET Browser Extension iniciada');
  connectToAgent();
  startHeartbeat();
});

// Conectar imediatamente
connectToAgent();
startHeartbeat();

// Listener para mensagens do popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStatus') {
    sendResponse({
      connected: isConnected,
      lastHeartbeat: state.lastHeartbeat
    });
  } else if (request.action === 'reconnect') {
    connectToAgent();
    sendResponse({ success: true });
  }
  return true;
});
