/**
 * COMET Browser Extension - Popup Script
 * Lógica da interface do usuário
 */

// Elementos do DOM
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const lastHeartbeat = document.getElementById('lastHeartbeat');
const reconnectBtn = document.getElementById('reconnectBtn');
const testBtn = document.getElementById('testBtn');

/**
 * Atualiza o status da conexão
 */
async function updateStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
    
    if (response.connected) {
      statusDot.className = 'status-dot connected';
      statusText.textContent = 'Conectado';
      
      if (response.lastHeartbeat) {
        const elapsed = Math.floor((Date.now() - response.lastHeartbeat) / 1000);
        lastHeartbeat.textContent = `${elapsed}s atrás`;
      } else {
        lastHeartbeat.textContent = 'Agora';
      }
    } else {
      statusDot.className = 'status-dot disconnected';
      statusText.textContent = 'Desconectado';
      lastHeartbeat.textContent = '-';
    }
  } catch (error) {
    console.error('Erro ao atualizar status:', error);
    statusDot.className = 'status-dot disconnected';
    statusText.textContent = 'Erro';
    lastHeartbeat.textContent = '-';
  }
}

/**
 * Reconecta ao agent
 */
async function reconnect() {
  reconnectBtn.disabled = true;
  reconnectBtn.textContent = '🔄 Reconectando...';
  
  try {
    await chrome.runtime.sendMessage({ action: 'reconnect' });
    
    setTimeout(() => {
      updateStatus();
      reconnectBtn.disabled = false;
      reconnectBtn.textContent = '🔄 Reconectar';
    }, 1000);
  } catch (error) {
    console.error('Erro ao reconectar:', error);
    reconnectBtn.disabled = false;
    reconnectBtn.textContent = '🔄 Reconectar';
  }
}

/**
 * Testa a conexão
 */
async function testConnection() {
  testBtn.disabled = true;
  testBtn.textContent = '🧪 Testando...';
  
  try {
    // Simula teste de conexão
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
    
    if (response.connected) {
      alert('✓ Conexão OK!\n\nDesktop Agent está respondendo normalmente.');
    } else {
      alert('✗ Sem conexão\n\nVerifique se o Desktop Agent está em execução.');
    }
  } catch (error) {
    alert('✗ Erro no teste\n\n' + error.message);
  } finally {
    testBtn.disabled = false;
    testBtn.textContent = '🧪 Testar Conexão';
  }
}

// Event listeners
reconnectBtn.addEventListener('click', reconnect);
testBtn.addEventListener('click', testConnection);

// Atualizar status ao abrir popup
updateStatus();

// Atualizar status a cada 2 segundos
setInterval(updateStatus, 2000);
